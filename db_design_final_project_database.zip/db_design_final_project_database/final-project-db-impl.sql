-- create enumeration table representing the affiliation of a hero
DROP TABLE IF EXISTS `mha_heros`.`affiliations`;
CREATE TABLE `mha_heros`.`affiliations` (
    `affiliation` varchar(45) NOT NULL,
    PRIMARY KEY (`affiliation`)
);

-- insert some affiliations
INSERT INTO affiliations
VALUES ('U.A. HIGH SCHOOL');
INSERT INTO affiliations
VALUES ('SHIKETSU HIGH SCHOOL');
INSERT INTO affiliations
VALUES ('KETSUBUTSU ACADEMY');
INSERT INTO affiliations
VALUES ('HERO ASSOCIATION');

-- create users table representing heros
DROP TABLE IF EXISTS `mha_heros`.`heros`;
CREATE TABLE `mha_heros`.`heros` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `first_name` varchar(45) DEFAULT NULL,
    `last_name` varchar(45) DEFAULT NULL,
    `username` varchar(45) DEFAULT NULL,
    `password` varchar(45) DEFAULT NULL,
    `email` varchar(45) DEFAULT NULL,
    `date_of_birth` date DEFAULT NULL,
    `blood_type` varchar(45) DEFAULT NULL,
    `affiliation` varchar(45) DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `heros_to_affiliation_idx`(`affiliation` ASC),
    CONSTRAINT `heros_to_affiliation`
		FOREIGN KEY (`affiliation`)
        REFERENCES `mha_heros`.`affiliations`(`affiliation`)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- insert some heros
INSERT INTO heros
VALUES (NULL, 'Toshinori', 'Yagi', 'All Might', 'All Might', 
	NULL, '9999-06-10', 'A', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Izuku', 'Midoriya', 'Deku', 'i<3a11might', 
	NULL, '9999-07-15', 'O', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Katsuki', 'Bakugo', 'Great Explosion Murder God Dynamight', NULL, 
	NULL, '9999-04-20', 'A', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Shoto', 'Todoroki', 'Shoto', 'daddyissues123', 
	NULL, '9999-01-11', 'O', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Mirio', 'Togata', 'Lemillion', 'lucas', 
	NULL, '9999-07-15', 'O', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Nejire', 'Hado', 'Nejire Chan', 'Nejire Chan', 
	NULL, '9999-10-06', 'B', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Tamaki', 'Amajiki', 'Suneater', NULL, 
	NULL, '9999-03-04', 'AB', 'U.A. HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Emi', 'Fukukado', 'Ms. Joke', 'Smile Hero', 
	NULL, '9999-02-05', NULL, 'KETSUBUTSU ACADEMY');
INSERT INTO heros
VALUES (NULL, 'Tatami', 'Nakagame', 'Turtle Neck', NULL, 
	NULL, '9999-01-23', 'A', 'KETSUBUTSU ACADEMY');
INSERT INTO heros
VALUES (NULL, 'Yo', 'Shindo', 'Grand', 'Grand', 
	NULL, '9999-05-13', 'AB', 'SHIKETSU HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Inasa', 'Yoarashi', 'Gale Force', 'Gale Force', 
	NULL, '9999-09-26', 'B', 'SHIKETSU HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Kemyi', 'Utsushimi', 'Maboromicamie', NULL, 
	NULL, '9999-08-15', 'O', 'SHIKETSU HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Nagamasa', 'Mora', 'Chewyee', 'Chewyee', 
	NULL, '9999-11-13', 'O', 'SHIKETSU HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Seiji', 'Shishikura', 'Sisicross', NULL, 
	NULL, '9999-02-09', 'A', 'SHIKETSU HIGH SCHOOL');
INSERT INTO heros
VALUES (NULL, 'Shino', 'Sosaki', 'Mandalay', NULL,
	NULL, '9999-05-01', 'A', 'HERO ASSOCIATION');
INSERT INTO heros
VALUES (NULL, 'Ryuko', 'Tsuchikawa', 'Pixie-Bob', NULL,
	NULL, '9999-06-26', 'AB', 'HERO ASSOCIATION');
INSERT INTO heros
VALUES (NULL, 'Tomoko', 'Shiretoko', 'Ragdoll', NULL,
	NULL, '9999-04-08', 'O', 'HERO ASSOCIATION');
INSERT INTO heros
VALUES (NULL, 'Yawara', 'Chatora', 'Tiger', NULL,
	NULL, '1984-02-29', 'A', 'HERO ASSOCIATION');
INSERT INTO heros
VALUES (NULL, 'Tsuyu', 'Asui', 'Froppy', 'kerokero',
	NULL, '9999-02-12', 'A', 'U.A. HIGH SCHOOL');

-- create domain object table representing quotes
DROP TABLE IF EXISTS `mha_heros`.`quotes`;
CREATE TABLE `mha_heros`.`quotes` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `text` varchar(140) DEFAULT NULL,
    `favorite` boolean DEFAULT NULL,
    `upvotes` int(10) DEFAULT NULL,
    `hero_id` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `quotes_to_hero_idx`(`hero_id` ASC),
    CONSTRAINT `quotes_to_hero`
		FOREIGN KEY (`hero_id`)
        REFERENCES `mha_heros`.`heros`(`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- insert some quotes
INSERT INTO quotes
VALUES (NULL, 'It\'s fine now. Why? Because I am here!', true, 9945162, 1);
INSERT INTO quotes
VALUES (NULL, 'You\'re next.', true, 1123, 1);
INSERT INTO quotes
VALUES (NULL, 'You can become a hero!', false, 321, 1);
INSERT INTO quotes
VALUES (NULL, 
	'I\'ll do my best! Whatever you say, All Might... I\'ll step up to the challenge!', 
    false, 1, 2);
INSERT INTO quotes
VALUES (NULL, 'I Don\'t Know But I\'ve \'To-GATA\' Go See!', true, 1000000, 5);
INSERT INTO quotes
VALUES (NULL, 'Die...!', false, 3, 3);
INSERT INTO quotes
VALUES (NULL, 'No, not that part.', false, 793, 1);
INSERT INTO quotes
VALUES (NULL, 'My mind\'s... blank...', true, 13, 7);

-- create domain object table representing quirks
DROP TABLE IF EXISTS `mha_heros`.`quirks`;
CREATE TABLE `mha_heros`.`quirks` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(45) DEFAULT NULL,
	`type` varchar(45) DEFAULT NULL,
    `description` varchar(140) DEFAULT NULL,
    PRIMARY KEY (`id`)
);

-- insert some quirks
INSERT INTO quirks
VALUES (NULL, 'One For All', 'emitter', 
	'a transferable Quirk that can be passed on from one user to the next');
INSERT INTO quirks
VALUES (NULL, 'Half-Cold Half-Hot', 'emitter', 
	'allows the user to generate ice, frost and cold from the right side of his body and fire, flames and heat from the left');
INSERT INTO quirks
VALUES (NULL, 'Frog', 'mutant', 'many frog-related abilities');
INSERT INTO quirks
VALUES (NULL, 'Naval Laser', 'emitter', 
	'the ability to fire sparkly laser beams from his navel');
INSERT INTO quirks
VALUES (NULL, 'Hardening', 'transformation', 
	'the power to harden any part of his body');
INSERT INTO quirks
VALUES (NULL, 'Hellflame', 'emitter', 
	'an extremely powerful Quirk that gives pyrokinetic abilities');
INSERT INTO quirks
VALUES (NULL, 'Manifest', 'transformation', 
	'the ability to enhance his limbs with the characteristics of anything he consumes');
INSERT INTO quirks
VALUES (NULL, 'Outburst', 'emitter', 
	'force others around her to burst into laughter so intense that it dulls their motor skills and cognitive abilities');

-- create domain object table representing super moves
DROP TABLE IF EXISTS `mha_heros`.`super_moves`;
CREATE TABLE `mha_heros`.`super_moves` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(45) DEFAULT NULL,
    `description` varchar(140) DEFAULT NULL,
    `range` varchar(45) DEFAULT NULL,
    `usage` varchar(45) DEFAULT NULL,
    `hero_id` int(11) DEFAULT NULL,
    `quirk_id` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
	INDEX `super_moves_to_hero_idx`(`hero_id` ASC),
    INDEX `super_moves_to_quirk_idx`(`quirk_id` ASC),
    CONSTRAINT `super_moves_to_hero`
		FOREIGN KEY (`hero_id`)
        REFERENCES `mha_heros`.`heros`(`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
	CONSTRAINT `super_moves_to_quirk`
		FOREIGN KEY (`quirk_id`)
        REFERENCES `mha_heros`.`quirks`(`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- insert some super moves
INSERT INTO super_moves
VALUES (NULL, 'Detroit Smash', 
	'simple punch focusing One For All\'s stockpiling power into the fist',
	'close', 'offense', 1, 1);
INSERT INTO super_moves
VALUES (NULL, 'United States of Smash', 
	'a smash attack that concentrates all of One For All\'s remaining power into All Might\'s fist',
	'close', 'offense', 1, 1);
INSERT INTO super_moves
VALUES (NULL, 'Delaware Smash', 
	'Izuku uses One For All at full power and flicks his fingers to create powerful shockwaves',
	'medium', 'offense', 2, 1);
INSERT INTO super_moves
VALUES (NULL, 'Texas Smash', 
	'a right punch with enough force that the wind pressure sends anything made of liquid flying away',
	'close', 'offense', 1, 1);
INSERT INTO super_moves
VALUES (NULL, 'Tremoring Earth', 
	'After two small pulses of energy, the ground surrounding him shakes and breaks apart, similar to an earthquake',
	'long', 'multi-target offense', 10, NULL);
INSERT INTO super_moves
VALUES (NULL, 'Blinder Touch Eyeball Crush', 
	'While phasing through an incoming attack, Mirio fakes going for his opponent\'s eyes with his fingers',
	'close', 'distraction', 5, NULL);
INSERT INTO super_moves
VALUES (NULL, 'Flashfire Fist', 
	'condenses Endeavor\'s flames into a white-hot point and is meant to act as a one-hit finisher',
	'medium', 'power up', NULL, 6);
INSERT INTO super_moves
VALUES (NULL, 'Prominence Burn', 
	'Endeavor uses the full might of his flames to emit a concentrated beam of heat from his body that is used to vaporize his target',
	'multi', 'offense', NULL, 6);
