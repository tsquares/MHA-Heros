package models;

public enum Affiliation {
  HERO_ASSOCIATION,
  KETSUBUTSU_ACADEMY,
  SHIKETSU_HIGH_SCHOOL,
  UA_HIGH_SCHOOL
}
